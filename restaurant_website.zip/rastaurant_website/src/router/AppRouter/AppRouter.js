import React, {Component, Fragment} from 'react';
import {Route,Switch} from "react-router-dom";
import HomePages from "../../pages/HomePages/HomePages";
import AboutPages from "../../pages/AboutPages/AboutPages";
import MainMenuPages from "../../pages/MenuPages/MainMenuPages";
import ContactPages from "../../pages/ContactPages/ContactPages";
import Reservation from "../../components/Reservation/Reservation";
import LunchMenuPages from "../../pages/MenuPages/LunchMenuPages";
import DinnerPages from "../../pages/MenuPages/DinnerPages";
import DrinksPages from "../../pages/MenuPages/DrinksPages";
import DessertPages from "../../pages/MenuPages/DessertPages";
import StoriesPages from "../../pages/StoriesPages/StoriesPages";

class AppRouter extends Component {
    render() {
        return (
            <Fragment>
                <Switch>
                    <Route exact path="/" component={HomePages}/>
                    <Route exact path="/about" component={AboutPages}/>
                    <Route exact path="/menu" component={MainMenuPages}/>
                    <Route exact path="/main" component={MainMenuPages}/>
                    <Route exact path="/lunch" component={LunchMenuPages}/>
                    <Route exact path="/dinner" component={DinnerPages}/>
                    <Route exact path="/drink" component={DrinksPages}/>
                    <Route exact path="/dessert" component={DessertPages}/>
                    <Route exact path="/stories" component={StoriesPages}/>
                    <Route exact path="/contact" component={ContactPages}/>
                    <Route exact path="" component={Reservation}/>


                </Switch>


            </Fragment>
        );
    }
}

export default AppRouter;