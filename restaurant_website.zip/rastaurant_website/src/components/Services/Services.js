import React, {Component, Fragment} from 'react';
import {Col, Container, Row} from "react-bootstrap";
import webLogo from '../../asset/images/Business.png'
import softLogo from '../../asset/images/birthday.png'
import mobileLogo from '../../asset/images/wedding.png'


class Services extends Component {
    render() {
        return (
            <Fragment>

                <Container fluid={true} className="mainServices text-center">
                    <Row className="title ">
                        <Col className="title " lg={12} md={12} sm={12} >
                           <div className="serviceMainTitle ">Services</div>
                           <div className="ServiceSubTitle">Catering Services</div>
                        </Col>
                    </Row>
                    <Row className="services">
                        <Col lg={4} md={6} sm={12} >
                            <div className="serviceCard text-center">
                                <img className="serviceImg" src={softLogo}/>
                                <h2 className="serviceName">Birthday Party</h2>
                                <p className="serviceDescription ">Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>

                            </div>

                        </Col>
                        <Col lg={4} md={6} sm={12}>
                            <div className="serviceCard text-center">

                                <img className="serviceImg" src={ webLogo}/>
                                <h2 className="serviceName">Business Meetings</h2>
                                <p className="serviceDescription">Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic</p>

                            </div>

                        </Col>
                        <Col lg={4} md={6} sm={12}>
                            <div className="serviceCard text-center">
                                <img className="serviceImg" src={mobileLogo}/>
                                <h2 className="serviceName">Wedding Party</h2>
                                <p className="serviceDescription">Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>

                            </div>

                        </Col>



                    </Row>


                    


                </Container>

            </Fragment>
        );
    }
}

export default Services;