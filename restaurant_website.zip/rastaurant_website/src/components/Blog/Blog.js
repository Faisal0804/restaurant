import React, {Component, Fragment} from 'react';
import {Col, Container, Row} from "react-bootstrap";
import blog1 from '../../asset/images/image_1.jpg'
import blog2 from '../../asset/images/image_2.jpg'
import blog3 from '../../asset/images/image_3.jpg'

class Blog extends Component {
    render() {
        return (
            <Fragment>

                <Container className=" blog text-center">
                    <Row className="title ">
                        <Col className="title " lg={12} md={12} sm={12} >
                            <div className="customerMainTitle ">Blog</div>
                            <div className="customerSubTitle ">Recent Posts</div>
                        </Col>
                    </Row>
                    <Row>
                        <Col lg={4} md={6} sm={12}>
                            <div className="blogCard text-center">
                                <img className="blogImg" src={ blog1}/>
                                <h2 className="blogSubTitle text-justify"> Sept. 06, 2019 Admin</h2>
                                <h2 className="blogName  text-justify">Taste the delicious foods in Asia</h2>
                                <a className="blogLink" href="">Read More</a>


                            </div>

                        </Col>
                        <Col lg={4} md={6} sm={12}>
                            <div className="blogCard text-center">

                                <img className="blogImg" src={blog2}/>
                                <h2 className="blogSubTitle text-justify"> Sept. 06, 2019 Admin</h2>
                                <h2 className="blogName text-justify">Taste the delicious foods in Asia</h2>
                                <a className="blogLink" href="">Read More</a>


                            </div>

                        </Col>
                        <Col lg={4} md={6} sm={12}>
                            <div className="blogCard  text-center">
                                <img className="blogImg" src={blog3}/>
                                <h2 className="blogSubTitle text-justify"> Sept. 06, 2019 Admin</h2>
                                 <h2 className="blogName text-justify">Taste the delicious foods in Asia</h2>
                                <a className="blogLink" href="">Read More</a>

                            </div>

                        </Col>





                    </Row>






                </Container>

            </Fragment>
        );
    }
}

export default Blog;