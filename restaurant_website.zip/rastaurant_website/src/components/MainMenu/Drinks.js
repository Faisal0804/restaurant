import React, {Component, Fragment} from 'react';
import {Col, Container, Row} from "react-bootstrap";
import softLogo from "../../asset/images/drink-1.jpg";
import webLogo from "../../asset/images/drink-2.jpg";
import mobileLogo from "../../asset/images/drink-3.jpg";
import Graphics from "../../asset/images/drink-4.jpg";
import online from "../../asset/images/drink-5.jpg";
import hosting from "../../asset/images/drink-6.jpg";
import {Link} from "react-router-dom";

class Drinks extends Component {
    render() {
        return (
            <Fragment>

                <Container className=" menu text-center">
                    <Row >
                        <Col lg={12} md={12} sm={12} className="MainMenu text-center ">
                            <Link className="MainMenuLink" to="/main">Breakfast</Link>
                            <Link className="MainMenuLink " to="/lunch">Lunch</Link>
                            <Link className="MainMenuLink " to="/dinner">Dinner</Link>
                            <Link  className="MainMenuLink " to="/drink">Drinks</Link>
                            <Link className="MainMenuLink " to="/dessert">Desert</Link>
                        </Col>

                    </Row>
                    <Row className="MainMenuCard">
                        <Col lg={3} md={6} sm={12} className=" p-0 mt-0">
                            <img className="menuImg" src={softLogo}/>
                        </Col>

                        <Col lg={3} md={6} sm={12} className="  mt-0">
                            <div className="  text-justify">
                                <h1 className="menuName ">Grilled Beef with potatoes</h1>
                                <h2 className="menuPrice ">$29</h2>
                                <p className="menuDescription ">Meat, Potatoes, Rice, Tomatoe</p>
                                <a className="Button" href="#"> Order now</a>

                            </div>


                        </Col>
                        <Col lg={3} md={6} sm={12} className=" p-0 mt-0">

                            <img className="menuImg" src={ webLogo}/>

                        </Col>
                        <Col lg={3} md={6} sm={12} className=" mt-0">
                            <div className="  text-justify">
                                <h1 className="menuName ">Grilled Beef with potatoes</h1>
                                <h2 className="menuPrice ">$29</h2>
                                <p className="menuDescription ">Meat, Potatoes, Rice, Tomatoe</p>
                                <a className="Button" href="#"> Order now</a>

                            </div>
                        </Col>

                        <Col lg={3} md={6} sm={12} className="mt-0">
                            <div className="  text-justify">
                                <h1 className="menuName ">Grilled Beef with potatoes</h1>
                                <h2 className="menuPrice ">$29</h2>
                                <p className="menuDescription ">Meat, Potatoes, Rice, Tomatoe</p>
                                <a className="Button" href="#"> Order now</a>

                            </div>
                        </Col>
                        <Col lg={3} md={6} sm={12} className=" p-0 mt-0">

                            <img className="menuImg" src={mobileLogo}/>

                        </Col>
                        <Col lg={3} md={6} sm={12} className="mt-0">
                            <div className=" text-justify">
                                <h1 className="menuName ">Grilled Beef with potatoes</h1>
                                <h2 className="menuPrice ">$29</h2>
                                <p className="menuDescription ">Meat, Potatoes, Rice, Tomatoe</p>
                                <a className="Button" href="#"> Order now</a>

                            </div>


                        </Col>



                        <Col lg={3} md={6} sm={12} className=" p-0 mt-0">

                            <img className="menuImg" src={Graphics}/>


                        </Col>

                        <Col lg={3} md={6} sm={12} className=" p-0 mt-0">
                            <img className="menuImg" src={online}/>

                        </Col>

                        <Col lg={3} md={6} sm={12} className="mt-0">
                            <div className=" text-justify">
                                <h1 className="menuName ">Grilled Beef with potatoes</h1>
                                <h2 className="menuPrice ">$29</h2>
                                <p className="menuDescription ">Meat, Potatoes, Rice, Tomatoe</p>
                                <a className="Button" href="#"> Order now</a>

                            </div>

                        </Col>




                        <Col lg={3} md={6} sm={12} className=" p-0 mt-0">

                            <img className="menuImg" src={hosting}/>

                        </Col>

                        <Col lg={3} md={6} sm={12} className="mt-0">
                            <div className=" text-justify">
                                <h1 className="menuName ">Grilled Beef with potatoes</h1>
                                <h2 className="menuPrice ">$29</h2>
                                <p className="menuDescription ">Meat, Potatoes, Rice, Tomatoe</p>
                                <a className="Button" href="#"> Order now</a>

                            </div>

                        </Col>





                    </Row>

                </Container>


            </Fragment>
        );
    }
}


export default Drinks;