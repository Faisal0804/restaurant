import React, {Component, Fragment} from 'react';

class MainAbout extends Component {
    render() {
        return (
            <Fragment>
                

            </Fragment>
        );
    }
}

export default MainAbout;