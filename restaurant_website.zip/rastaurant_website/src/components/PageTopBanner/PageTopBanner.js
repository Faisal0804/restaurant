import React, {Component, Fragment} from 'react';
import {Col, Container, Row} from "react-bootstrap";



class PagesTopBanner extends Component {
    render() {
        return (
            <Fragment>
                <Container fluid={true} className="topFixedPage p-0" >
                    <div className="topPageOverlay">
                        <Container>



                                    <h4 className="pageTitle text-center" >{this.props.pagesTitle}</h4>



                        </Container>
                    </div>
                </Container>

            </Fragment>
        );
    }
}

export default PagesTopBanner;