import React, {Component, Fragment} from 'react';
import {Button, Col, Container, Row} from "react-bootstrap";
import aboutImg from '../../asset/images/about.jpg'
import aboutOneImg from '../../asset/images/about-1.jpg'



class AboutUs extends Component {
    render() {
        return (
            <Fragment>
                <Container className="mt-5">
                    <Row>
                        <Col sm={12} lg={6} md={12}>
                            <Row>
                              <Col sm={12} lg={6} md={12}>

                              <img  className="aboutImg" src={aboutImg}/>
                              </Col>

                              <Col sm={12} lg={6} md={12}>

                             <img className="aboutOneImg" src={aboutOneImg}/>


                              </Col>
                             </Row>
                            </Col>

                        <Col sm={12} lg={6} md={12}>
                            <Row className="title ">
                                <Col className="title " lg={12} md={12} sm={12} >
                                    <div className="aboutMainTitle text-justify">About</div>
                                    <div className="AboutSubTitle text-justify">Mad Grill</div>
                                </Col>
                            </Row>
                            <p className="AboutDescription text-justify">

                                A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.
                            </p>

                            <h1 className="AboutDays">Mon - Fri<h2 className="AboutTime">8 AM - 11 PM</h2></h1>

                            <h1 className="AboutContact">+ 1-978-123-4567</h1>




                        </Col>
                    </Row>
                </Container>



            </Fragment>
        );
    }
}

export default AboutUs;