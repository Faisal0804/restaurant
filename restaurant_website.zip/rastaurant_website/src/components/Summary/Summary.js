import React, {Component, Fragment} from 'react';
import { Col, Container, Row} from "react-bootstrap";
import CountUp from 'react-countup';
import VisibilitySensor from "react-visibility-sensor";


class Summary extends Component {
    render() {
        return (
            <Fragment>

                   <Container className="text-center">
                            <Row>
                                <Col lg={8} md={6} sm={12}>

                                    <Row className="countSection"><Col>
                                            <h1 className="countNumber">
                                                <CountUp start={0} end={10}>
                                                    {({ countUpRef, start }) => (
                                                        <VisibilitySensor onChange={start} delayedCall>
                                                            <span ref={countUpRef} />
                                                        </VisibilitySensor>
                                                    )}
                                                </CountUp>

                                            </h1>
                                            <h4 className="countTitle">Years of Experienced</h4>
                                    </Col>

                                        <Col>
                                            <h1 className="countNumber">

                                                <CountUp start={0} end={100}>
                                                    {({ countUpRef, start }) => (
                                                        <VisibilitySensor onChange={start} delayedCall>
                                                            <span ref={countUpRef} />
                                                        </VisibilitySensor>
                                                    )}
                                                </CountUp>
                                            </h1>
                                            <h4 className="countTitle">Menus/Dish</h4>
                                        </Col>
                                        <Col>
                                            <h1 className="countNumber">
                                                <CountUp start={0} end={40}>
                                                    {({ countUpRef, start }) => (
                                                        <VisibilitySensor onChange={start} delayedCall>
                                                            <span ref={countUpRef} />
                                                        </VisibilitySensor>
                                                    )}
                                                </CountUp>
                                            </h1>
                                            <h4 className="countTitle">Staffs</h4>

                                        </Col>
                                        <Col>
                                            <h1 className="countNumber">
                                                <CountUp start={0} end={15000}>
                                                    {({ countUpRef, start }) => (
                                                        <VisibilitySensor onChange={start} delayedCall>
                                                            <span ref={countUpRef} />
                                                        </VisibilitySensor>
                                                    )}
                                                </CountUp>
                                            </h1>
                                            <h4 className="countTitle">Happy Customers</h4>
                                        </Col>
                                    </Row>
                                </Col>

                                <Col lg={4} md={6} sm={12}>
                                    <p className="SummaryDesc text-justify"> A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
                                </Col>

                            </Row>
                        </Container>


            </Fragment>
        );
    }
}

export default Summary;