import React, {Component,Fragment} from 'react';
import {Nav, Navbar, NavDropdown} from "react-bootstrap";
import {NavLink} from "react-router-dom";


class TopNavigation extends Component {
    constructor(props){
        super();
        this.state={
            navBarTitle:"navTitle",
            navBarBack:"navBackground",
            navBarItem:"navItem",
            pageTitle:props.title
        }
    }
    onScroll=()=>{
        if(window.scrollY>100){
            this.setState({navBarTitle:'navTitleScroll', navBarBack:'navBackgroundScroll',navBarItem:'navItemScroll'})
        }
        else if(window.scrollY<100){
            this.setState({navBarTitle:'navTitle',navBarBack:'navBackground',navBarItem:'navItem'})
        }
    }
    componentDidMount() {
        window.addEventListener('scroll',this.onScroll)
    }
    render() {
        return (
            <Fragment>
                <title>{this.state.pageTitle}</title>
                <Navbar className={this.state.navBarBack} fixed="top" collapseOnSelect expand="lg">
                    <Navbar.Brand className={this.state.navBarTitle}><img src={this.state.navBarLogo}/>    Mad Grill</Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="mr-auto">
                        </Nav>
                        <Nav className="navVarMain">
                            <Nav.Link><NavLink className={this.state.navBarItem} exact activeStyle={{color:'#C8A97E'}} to="/">HOME</NavLink></Nav.Link>
                            <Nav.Link><NavLink className={this.state.navBarItem} exact activeStyle={{color:'#C8A97E'}} to="/about">ABOUT</NavLink></Nav.Link>
                            <Nav.Link><NavLink className={this.state.navBarItem} exact activeStyle={{color:'#C8A97E'}} to="/menu">MENU</NavLink></Nav.Link>
                            <Nav.Link><NavLink className={this.state.navBarItem} exact activeStyle={{color:'#C8A97E'}} to="/stories">STORIES</NavLink></Nav.Link>
                            <Nav.Link><NavLink className={this.state.navBarItem} exact activeStyle={{color:'#C8A97E'}} to="/contact">CONTACT</NavLink></Nav.Link>
                            <Nav.Link><NavLink className={this.state.navBarItem} exact activeStyle={{color:'#C8A97E'}} to="">BACK A TABLE</NavLink></Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>
            </Fragment>
        );
    }
}
export default TopNavigation;