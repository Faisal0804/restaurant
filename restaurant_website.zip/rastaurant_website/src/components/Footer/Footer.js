
import React, {Component,Fragment} from 'react';
import GoogleMapReact from 'google-map-react';
import {Col, Container, Row} from "react-bootstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faEnvelope, faPhone} from "@fortawesome/free-solid-svg-icons";
import {faFacebook,faYoutube} from "@fortawesome/free-brands-svg-icons";
import fb from "../../asset/images/fb.svg"
import Youtube from "../../asset/images/Youtubef.png"
import instagram1 from "../../asset/images/insta-1.jpg"
import instagram2 from "../../asset/images/insta-2.jpg"
import instagram3 from "../../asset/images/insta-3.jpg"
import instagram4 from "../../asset/images/insta-4.jpg"
import instagram5 from "../../asset/images/insta-5.jpg"
import instagram6 from "../../asset/images/insta-6.jpg"



class Footer extends Component {


    render() {
        return (
            <Fragment>
                <Container fluid={true} className=" footerSection">
                    <Row>
                        <Col lg={3} md={6} sm={12} className="p-3 pl-5 text-justify">
                            <h1 className="footerName ">Follow Me</h1>
                            <hr  className="hr "/>
                            <p className="footerPara" href="#">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.  </p><br/>

                            <a className="footerDescription" href="#"><img className="socialLink" src={fb} />  Facebook Page</a><br/>

                            <a className="footerDescription"  href="#"><img className="socialLink" src={Youtube}/> YouTube</a><br/>
                        </Col>
                        <Col lg={3} md={6} sm={12} className="p-3 pl-5 text-justify">
                            <h1 className="footerName ">Open Hours</h1>
                            <hr  className="hr "/>
                            <Row>
                                <Col lg={6} md={6} sm={12} className="p-0 text-justify">
                                    <h2 className="footerDay">Monday</h2><br/>
                                    <h2 className="footerDay">Tuesday</h2><br/>
                                    <h2 className="footerDay">Wednesday</h2><br/>
                                    <h2 className="footerDay">Thursday</h2><br/>
                                    <h2 className="footerDay">Friday</h2><br/>
                                    <h2 className="footerDay">Saturday</h2><br/>
                                    <h2 className="footerDay">Sunday</h2>


                                </Col>
                                <Col lg={6} md={6} sm={12} className=" text-justify">
                                    <h2 className="footerTime">  9:00 - 24:00 </h2><br/>
                                    <h2 className="footerTime">  9:00 - 24:00 </h2><br/>
                                    <h2 className="footerTime">  9:00 - 24:00 </h2><br/>
                                    <h2 className="footerTime">  9:00 - 24:00 </h2><br/>
                                    <h2 className="footerTime">  9:00 - 24:00 </h2><br/>
                                    <h2 className="footerTime">  9:00 - 24:00 </h2><br/>
                                    <h2 className="footerTime">  9:00 - 24:00 </h2>

                                </Col>

                            </Row>


                        </Col>
                        <Col lg={3} md={6} sm={12} className="p-3 text-justify">
                            <h1 className="footerName">Instagram</h1>
                            <hr  className="hr "/>
                            <img className="instaPic" src={instagram1}/>
                            <img className="instaPic" src={instagram2}/>
                            <img className="instaPic" src={instagram3}/>
                            <img className="instaPic" src={instagram4}/>
                            <img className="instaPic" src={instagram5}/>
                            <img className="instaPic" src={instagram6}/>

                        </Col>
                        <Col lg={3} md={6} sm={12} className="p-3 text-justify">
                            <h1 className="footerName">Address</h1>
                            <hr  className="hr "/>
                            <p className="footerDescription" > # RangMohol tower,Bandor bazar, Sylhet</p>
                            <p className="footerDescription" > <FontAwesomeIcon  icon={faEnvelope} /> Email:faisal.lu.ac@gmail.com</p>
                            <p className="footerDescription" > <FontAwesomeIcon  icon={faPhone} /> +8801710-903032</p>
                        </Col>


                    </Row>
                </Container>

                <Container fluid={true} className="text-center copyrightSection">
                    <hr  className="hrCopy w-100"/>
                    <a className="copyrightLink" href="#">All Right Reserved by Infinity Flame Soft &copy; 2019</a>
                </Container>

            </Fragment>
        );
    }
}

export default Footer;