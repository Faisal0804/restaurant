import React, {Component, Fragment} from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import {Col, Container, Row} from "react-bootstrap";
import ReviewOne from '../../asset/images/person_1.jpg'
import ReviewTwo from '../../asset/images/person_2.jpg'
import ReviewThree from '../../asset/images/person_3.jpg'
import ReviewIcon from '../../asset/images/reviewIcon.png'


class Customer extends Component {
    render() {

        var settings= {
            autoplaySpeed:500,
            autoplay:true,
            dots: true,
            infinite: true,
            speed: 3000,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow:1,
                        slidesToScroll: 1,
                        initialSlide: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        };



        return (
                <Fragment>

                    <Container fluid={true} className="clientSection text-center">
                        <Row className="title ">
                            <Col className="title " lg={12} md={12} sm={12} >
                                <div className="customerMainTitle ">Testimony</div>
                                <div className="customerSubTitle ">Happy Customer</div>
                            </Col>
                        </Row>
                        <Slider {...settings}>

                                    <div className="reviewSection">

                                        <img className="circleImg " src={ReviewOne}/>

                                        <h1 className="clientName">Shafi Mohammed Nahiyan</h1>
                                        <h4 className="clientTitle">Customer</h4>
                                        <p className="ClientDescription" >"Our group is working with this team for more than 2 years now. They are undoubtedly talented and we are more than happy to work with them."</p>
                                    </div>

                            <div className="reviewSection">
                                <img className="circleImg" src={ReviewTwo}/>
                                <h1 className="clientName">Md. Asaduzzaman Khan</h1>
                                <h4 className="clientTitle">Customer</h4>
                                <p className="ClientDescription">"Infinity Flame Software compnay knows what they are doing and they proved to us several times."</p>
                            </div>


                            <div className="reviewSection">
                                <img className="circleImg" src={ReviewThree}/>
                                <h1 className="clientName">Abu Naser Salauddin</h1>
                                <h4 className="clientTitle">Customer</h4>
                                <p className="ClientDescription">"They are humble, generous, passionate, dedicated, creative and talented."</p>
                            </div>

                            <div className="reviewSection">
                                <img className="circleImg" src={ReviewTwo}/>
                                <h1 className="clientName">Md. Asaduzzaman Khan</h1>
                                <h4 className="clientTitle">Customer</h4>
                                <p className="ClientDescription">"Infinity Flame Software compnay knows what they are doing and they proved to us several times."</p>
                            </div>









                        </Slider>



                    </Container>


                </Fragment>
            );
        }
    }

export default Customer;