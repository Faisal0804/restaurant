import React, {Component, Fragment} from 'react';
import {Button, Card, Col, Container, Form, Row} from "react-bootstrap";

class Reservation extends Component {
    render() {
        return (
            <Fragment>

                <Container fluid={true} className="reservationBanner reservationSection p-0" >
                    <div className="reservationBannerOverlay">
                        <Container className="text-center">


                            <Row>

                                <Col lg={8} md={6} sm={12}>
                                    <Card className="workCard">
                                        <Card.Body>
                                            <Card.Title className="cardTitle ">
                                                <Row className="">
                                                <Col className="res " lg={12} md={12} sm={12} >
                                                    <div className="resMainTitle ">Book a table</div>
                                                    <div className="resSubTitle">Make Reservation</div>
                                                </Col>
                                            </Row >
                                            </Card.Title>
                                            <Card.Text className="text-justify">
                                              <Row>
                                                  <Col lg={6} md={12} sm={12}>

                                                <Form>

                                                    <Form.Group>
                                                        <Form.Label   className="formDescription " >Name</Form.Label>
                                                        <Form.Control placeholder="Enter Name" type="text"  />
                                                    </Form.Group>
                                                    <Form.Group>
                                                        <Form.Label className="formDescription"  placeholder=" Name">Phone</Form.Label>
                                                        <Form.Control placeholder="Enter phone" type="text"  />
                                                    </Form.Group>
                                                    <Form.Group>
                                                        <Form.Label className="formDescription"  placeholder=" time">Time</Form.Label>
                                                        <Form.Control  placeholder="Enter Time" type="email" />
                                                    </Form.Group>


                                                </Form>
                                                  </Col>
                                                  <Col lg={6} md={12} sm={12}>

                                                  <Form>


                                                      <Form.Group>
                                                          <Form.Label className="formDescription " >E-mail</Form.Label>
                                                          <Form.Control placeholder="Enter E-mail" Time type="mail"  />
                                                      </Form.Group>
                                                      <Form.Group>
                                                          <Form.Label className="formDescription" >Address</Form.Label>
                                                          <Form.Control placeholder="Enter phone" type="phone"  />
                                                      </Form.Group>
                                                      <Form.Group>
                                                          <Form.Label className="formDescription" >number of Person</Form.Label>
                                                          <Form.Control  type="number">

                                                          </Form.Control>
                                                      </Form.Group>



                                                  </Form>
                                                </Col>


                                              </Row>

                                            </Card.Text>
                                            <a className="ResButton" href="#"> Make a Conversation</a>

                                        </Card.Body>
                                    </Card>


                                </Col>

                                <Col lg={4} md={6} sm={12}>



                                </Col>


                            </Row>
                        </Container>
                    </div>
                </Container>

            </Fragment>
        );
    }
}

export default Reservation;