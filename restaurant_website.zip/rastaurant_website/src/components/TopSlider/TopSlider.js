import React, {Component, Fragment} from 'react';
import '../../asset/css/custome.css'
import '../../asset/css/bootstrap.min.css'
import {Button, Col, Container, Navbar, Row} from "react-bootstrap";
import Slider from 'react-animated-slider';
import 'react-animated-slider/build/horizontal.css';
import breOne from '../../asset/images/breakfast-1.jpg'
import breTwo from '../../asset/images/breakfast-2.jpg'
import breThree from '../../asset/images/breakfast-3.jpg'
import breFour from '../../asset/images/breakfast-4.jpg'





class TopSlider extends Component {
    render() {

        var settings= {
            autoplaySpeed:3000,
            autoplay:true,
            dots: false,
            infinite: true,
            speed: 3000,
            slider: 'slider',
            buttonDisabled: 'disabled',
            track: 'track',
            slide: 'slide',
            hidden: 'hidden',
            previous: 'previous',
            current: 'current',
            height:1000,
            next: 'next',
            animateIn: 'animateIn',
            animateOut: 'animateOut',


        }


        return (
            <Fragment>
                <Container fluid={true} className=" slider p-0">
                    <Slider  {...settings}  >
                       <div>
                            <Row className="text-center">
                                <Col lg={12} md={12} sm={12} className="topFixedBanner">

                                    <div className="topBannerOverlay">

                                        <Container className="topContent text-center">

                                                    <h1 className="topTitle" >MadGrill</h1>

                                                    <h4 className="topSubTitle">BEST RESTAURANT</h4>



                                            <Row className="text-center">
                                                <Col lg={3} md={6} sm={12} >
                                                    <img className="breImg" src={breOne}/>
                                                    <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                    <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>
                                                </Col>
                                                <Col lg={3} md={6} sm={12}>
                                                    <img className="breImg" src={breTwo}/>
                                                    <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                    <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                                </Col>

                                                <Col lg={3} md={6} sm={12}>
                                                    <img className="breImg" src={breThree}/>
                                                    <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                    <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                                </Col>

                                                <Col lg={3} md={6} sm={12}>
                                                    <img className="breImg" src={breFour}/>
                                                    <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                    <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                                </Col>


                                            </Row>

                                        </Container>
                                    </div>
                                </Col>
                            </Row>
                       </div>

                        <div>
                        <Row>

                            <Col lg={12} md={12} sm={12} className="topFixedBannerTwo">

                                <div className="topBannerOverlay">

                                    <Container className="topContent text-center">

                                        <h1 className="topTitle" >MadGrill</h1>

                                        <h4 className="topSubTitle">NUTRITIOUS AND TASTY </h4>

                                        <Row className="text-center">
                                            <Col lg={3} md={6} sm={12} >
                                                <img className="breImg" src={breOne}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>
                                            </Col>
                                            <Col lg={3} md={6} sm={12}>
                                                <img className="breImg" src={breTwo}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                            </Col>

                                            <Col lg={3} md={6} sm={12}>
                                                <img className="breImg" src={breThree}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                            </Col>

                                            <Col lg={3} md={6} sm={12}>
                                                <img className="breImg" src={breFour}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                            </Col>


                                        </Row>



                                    </Container>
                                </div>
                            </Col>
                        </Row>
                        </div>

                        <div>
                        <Row>
                            <Col lg={12} md={12} sm={12} className="topFixedBannerThree">

                                  <div className="topBannerOverlay">

                                    <Container className="topContent text-center">

                                        <h1 className="topTitle" >MadGrill</h1>

                                        <h4 className="topSubTitle">DELICIOUS AND HYGIENIC</h4>
                                
                                        <Row className="text-center">
                                            <Col lg={3} md={6} sm={12} >
                                                <img className="breImg" src={breOne}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>
                                            </Col>
                                            <Col lg={3} md={6} sm={12}>
                                                <img className="breImg" src={breTwo}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                            </Col>

                                            <Col lg={3} md={6} sm={12}>
                                                <img className="breImg" src={breThree}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                            </Col>

                                            <Col lg={3} md={6} sm={12}>
                                                <img className="breImg" src={breFour}/>
                                                <h1 className="breTitle">Grilled Beef with potatoes</h1>
                                                <p className="breSubTitle">Meat, Potatoes, Rice, Tomatoe </p>


                                            </Col>


                                        </Row>


                                    </Container>
                                </div>
                            </Col>
                        </Row>
                        </div>

                    </Slider>

                </Container>

            </Fragment>
        );
    }
}

export default TopSlider;