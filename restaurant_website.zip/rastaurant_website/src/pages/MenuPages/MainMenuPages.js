import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import MainMenu from "../../components/MainMenu/MainMenu";
import Footer from "../../components/Footer/Footer";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class MainMenuPages extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="Menu"/>
                <PagesTopBanner pagesTitle="Special Item"/>
                <MainMenu/>
                <Footer/>


            </Fragment>
        );
    }
}

export default MainMenuPages;