import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import DinnerMenu from "../../components/MainMenu/DinnerMenu";
import Footer from "../../components/Footer/Footer";
import Drinks from "../../components/MainMenu/Drinks";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class DrinksPages extends Component {

    render() {
        return (
            <Fragment>
                <TopNavigation title="Drinks Menu"/>
                <PagesTopBanner pagesTitle="Drinks Item"/>
                <Drinks/>
                <Footer/>

            </Fragment>
        );
    }
}

export default DrinksPages;