import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import LunchMenu from "../../components/MainMenu/LunchMenu";
import Footer from "../../components/Footer/Footer";
import DinnerMenu from "../../components/MainMenu/DinnerMenu";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class DinnerPages extends Component {

    render() {
        return (
            <Fragment>
                <TopNavigation title="Dinner Menu"/>
                <PagesTopBanner pagesTitle="Dinner Item"/>
                <DinnerMenu/>
                <Footer/>

            </Fragment>
        );
    }
}

export default DinnerPages;