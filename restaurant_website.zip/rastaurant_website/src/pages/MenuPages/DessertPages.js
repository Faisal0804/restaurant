import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import Drinks from "../../components/MainMenu/Drinks";
import Footer from "../../components/Footer/Footer";
import Desserts from "../../components/MainMenu/Desserts";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class DessertPages extends Component {

    render() {
        return (
            <Fragment>
                <TopNavigation title="Dessert Menu"/>
                <PagesTopBanner pagesTitle="Dessert Item"/>
                <Desserts/>
                <Footer/>

            </Fragment>
        );
    }
}

export default DessertPages;