import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import LunchMenu from "../../components/MainMenu/LunchMenu";
import Footer from "../../components/Footer/Footer";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class LunchMenuPages extends Component {

    render() {
        return (
            <Fragment>
                <TopNavigation title="Lunch Menu"/>
                <PagesTopBanner pagesTitle="Lunch Item"/>
                <LunchMenu/>
                <Footer/>
            </Fragment>
        );
    }
}

export default LunchMenuPages;