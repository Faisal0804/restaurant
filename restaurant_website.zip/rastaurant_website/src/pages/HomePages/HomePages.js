import React, {Component, Fragment} from 'react';
import TopSlider from "../../components/TopSlider/TopSlider";
import AboutUs from "../../components/AboutUs/AboutUs";
import Summary from "../../components/Summary/Summary";
import Services from "../../components/Services/Services";
import Menu from "../../components/Menu/Menu";
import Reservation from "../../components/Reservation/Reservation";
import Customer from "../../components/Customer/Customer";
import Blog from "../../components/Blog/Blog";
import Footer from "../../components/Footer/Footer";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class HomePages extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation  title="Restaurant" />
                <TopSlider/>
                <AboutUs/>
                <Summary/>
                <Services/>
                <Menu/>
                <Reservation/>
                <Customer/>
                <Blog/>
                <Footer/>

            </Fragment>
        );
    }
}

export default HomePages;