import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import Stories from "../../components/Stories/Stories";
import Footer from "../../components/Footer/Footer";
import AboutUs from "../../components/AboutUs/AboutUs";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class AboutPages extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="About us"/>
                <PagesTopBanner pagesTitle="About Us"/>
                <AboutUs/>
                <Footer/>

            </Fragment>
        );
    }
}

export default AboutPages;