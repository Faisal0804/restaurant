import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import Stories from "../../components/Stories/Stories";
import Footer from "../../components/Footer/Footer";
import MainContact from "../../components/MainContact/MainContact";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class ContactPages extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="Contact"/>
                <PagesTopBanner pagesTitle="Contact Us"/>
                <MainContact/>
                <Footer/>

            </Fragment>

        );
    }
}

export default ContactPages;