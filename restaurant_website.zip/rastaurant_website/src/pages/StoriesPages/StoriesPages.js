import React, {Component, Fragment} from 'react';
import PagesTopBanner from "../../components/PageTopBanner/PageTopBanner";
import Desserts from "../../components/MainMenu/Desserts";
import Stories from "../../components/Stories/Stories";
import Footer from "../../components/Footer/Footer";
import TopNavigation from "../../components/TopNavigation/TopNavigation";

class StoriesPages extends Component {
    componentDidMount() {
        window.scroll(0,0)
    }
    render() {
        return (
            <Fragment>
                <TopNavigation title="Stories" />
                <PagesTopBanner pagesTitle="Blog"/>
                <Stories/>
                <Footer/>

            </Fragment>

        );
    }
}

export default StoriesPages;